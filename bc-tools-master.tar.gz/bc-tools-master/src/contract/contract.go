package contract

import (
	"context"
	"crypto/ecdsa"
	"errors"
	"github.com/ethereum/go-ethereum/accounts/abi/bind"
	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/ethereum/go-ethereum/crypto"
	"github.com/ethereum/go-ethereum/ethclient"
	"golang.org/x/crypto/sha3"
	"math/big"
)

type contract struct {
	Common *token.Contract
	cli    *ethclient.Client
	addr   common.Address
}

func NewContractAt(address string, cli *ethclient.Client) (*contract, error) {
	addr := common.HexToAddress(address)
	ins, err := token.NewContract(addr, cli)
	if err != nil {
		return nil, err
	}
	return &contract{
		Common: ins,
		cli:    cli,
	}, nil
}

// 交易
func (c *contract) TransferUsePriKey(priKey string, toAddress string, weiAmount *big.Int) (string, error) {
	client := c.cli

	// 1. 私钥
	privateKey, err := crypto.HexToECDSA(priKey)
	if err != nil {
		return "", err
	}
	// 2. 公钥
	publicKey := privateKey.Public()
	publicKeyECDSA, ok := publicKey.(*ecdsa.PublicKey)
	if !ok {
		return "", errors.New("cannot assert type: publicKey is not of type *ecdsa.PublicKey")
	}

	from := crypto.PubkeyToAddress(*publicKeyECDSA)
	to := common.HexToAddress(toAddress)

	// nonce gasPrice gasLimit
	nonce, err := client.PendingNonceAt(context.Background(), from)
	if err != nil {
		return "", err
	}
	gasPrice, err := client.SuggestGasPrice(context.Background())
	if err != nil {
		return "", err
	}
	gasLimit := uint64(90000)

	// data 部分
	transferFnSignature := []byte("transfer(address,uint256)")
	hash := sha3.NewLegacyKeccak256()
	hash.Write(transferFnSignature)
	methodID := hash.Sum(nil)[:4]
	paddedAddress := common.LeftPadBytes(to.Bytes(), 32)
	paddedAmount := common.LeftPadBytes(weiAmount.Bytes(), 32)
	var data []byte
	data = append(data, methodID...)
	data = append(data, paddedAddress...)
	data = append(data, paddedAmount...)

	// tx
	value := big.NewInt(0)
	tx := types.NewTransaction(nonce, c.addr, value, gasLimit, gasPrice, data)

	chainID, err := client.NetworkID(context.Background())
	if err != nil {
		return "", err
	}

	signedTx, err := types.SignTx(tx, types.NewEIP155Signer(chainID), privateKey)
	if err != nil {
		return "", err
	}

	// SendTransaction
	err = client.SendTransaction(context.Background(), signedTx)
	if err != nil {
		return "", err
	}

	txHash := signedTx.Hash().Hex()
	return txHash, nil
}

// 查询余额
func (c *contract) BalanceOf(address string) (*big.Int, error) {
	return c.Common.BalanceOf(&bind.CallOpts{}, common.HexToAddress(address))
}

// 名称
func (c *contract) Name() (string, error) {
	return c.Common.Name(&bind.CallOpts{})
}

// 符号
func (c *contract) Symbol() (string, error) {
	return c.Common.Symbol(&bind.CallOpts{})
}

// 精度
func (c *contract) Decimals() (uint8, error) {
	return c.Common.Decimals(&bind.CallOpts{})
}

package core

import (
    "os"
    "strconv"
    "strings"
    "time"
)

const (
    AppDirName = ".zlabBCTools"
)

func homeDir() string {
    if os.Getenv("DIR_HOME") == "" {
        return os.Getenv("HOME") + "/" + AppDirName
    }
    return strings.TrimRight(os.Getenv("DIR_HOME"), "/") + "/" + AppDirName
}

func workDir(name string) string {
    dir := homeDir() + "/" + strings.Trim(name, "/")
    if _, err := os.Stat(dir); err != nil {
        os.MkdirAll(dir, 0755)
    }
    return dir
}

func newLogName(name string, version string) string {
    // 1610706262_2021_01_15_0.8.2-xx_data.txt
    now := time.Now()
    return strconv.FormatInt(now.Unix(), 10) + now.Format("_2006_01_02_") + version + "-" + name
}

func InitHomeEnv() {
    if _, err := os.Stat(homeDir()); err != nil {
        os.MkdirAll(homeDir(), 0755)
    }
}

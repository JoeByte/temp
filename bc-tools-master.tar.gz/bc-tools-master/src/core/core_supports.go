package core

type supports struct {
}

func getSupportsInstance() *supports {
    return &supports{}
}

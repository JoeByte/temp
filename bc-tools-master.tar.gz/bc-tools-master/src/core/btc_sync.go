package core

import (
    "bufio"
    "encoding/base64"
    "encoding/hex"
    "encoding/json"
    "errors"
    "fmt"
    "github.com/gomodule/redigo/redis"
    log "github.com/sirupsen/logrus"
    "github.com/zlabwork/go-chain/bitcoin"
    "github.com/zlabwork/go-zlibs"
    "io"
    "io/ioutil"
    "os"
    "strconv"
    "strings"
    "sync"
    "time"
)

var (
    keyNameTxOut   = "utxo"
    keyNameHash160 = "hash160"
    dirTX          = "txs"
    fhIn, fhOut    *os.File
    numCPU         int // cpu处理数
    w              sync.WaitGroup
)

type TxOut struct {
    TxId string
    VOut int
}

type blockDesc struct {
    Result struct {
        Hash              string            `json:"hash"`
        Height            int               `json:"height"`
        MerkleRoot        string            `json:"merkleroot"`
        Tx                []json.RawMessage `json:"tx"`
        Time              int               `json:"time"`
        NTx               int               `json:"nTx"`
        PreviousBlockHash string            `json:"previousblockhash"`
        NextBlockHash     string            `json:"nextblockhash"`
    } `json:"result"`
    Error interface{} `json:"error"`
    ID    string      `json:"id"`
}

type txCoinBase struct {
    Txid string `json:"txid"`
    Vin  []struct {
        Coinbase string `json:"coinbase"`
    } `json:"vin"`
    Vout []struct {
        Value float64 `json:"value"`
        N     int     `json:"n"`
    } `json:"vout"`
}

type txNormal struct {
    Txid string `json:"txid"`
    Vin  []struct {
        Txid string `json:"txid"`
        Vout int    `json:"vout"`
    } `json:"vin"`
    Vout []struct {
        Value float64 `json:"value"`
        N     int     `json:"n"`
    } `json:"vout"`
}

type vOutDesc struct {
    Value        float64 `json:"value"`
    N            int     `json:"n"`
    ScriptPubKey struct {
        Asm       string   `json:"asm"`
        Hex       string   `json:"hex"`
        ReqSigs   int      `json:"reqSigs"`
        Type      string   `json:"type"`
        Addresses []string `json:"addresses"`
    } `json:"scriptPubKey"`
}

type btcWorker struct {
    redis    redis.Conn
    req      *zlibs.HttpLib
    endpoint string
    bfData   *bloomFilter
}

func NewBTCSync() *btcWorker {
    var err error
    numCPU, err = strconv.Atoi(os.Getenv("BF_CPU"))
    if err != nil {
        panic(err)
    }
    redisIns, _ := Instance().Redis()
    return &btcWorker{
        redis: redisIns.Get(),
        req:   zlibs.NewHttpLib(),
    }
}

func (work *btcWorker) request(method string, params []interface{}) ([]byte, error) {
    reqId := uniqueID()
    type rd struct {
        Jsonrpc string        `json:"jsonrpc"`
        Id      string        `json:"id"`
        Method  string        `json:"method"`
        Params  []interface{} `json:"params"`
    }

    b, err := json.Marshal(rd{
        Jsonrpc: "1.0",
        Id:      reqId,
        Method:  method,
        Params:  params,
    })
    if err != nil {
        return nil, err
    }
    data := string(b)
    header := make(map[string]string)
    token := base64.StdEncoding.EncodeToString([]byte(os.Getenv("BTC_RPC_USER") + ":" + os.Getenv("BTC_RPC_PASS")))
    header["Authorization"] = "Basic " + token
    work.req.SetHeaders(header)
    resp, err := work.req.RequestRaw("POST", work.endpoint, []byte(data))
    if err != nil {
        return nil, err
    }
    defer resp.Body.Close()

    body, err := ioutil.ReadAll(resp.Body)
    if resp.StatusCode != 200 {
        return nil, errors.New(fmt.Sprintf("code: %d, message: %s", resp.StatusCode, strings.Trim(string(body), "\n")))
    }
    return body, err
}

func (work *btcWorker) SetEndpoint(addr string) {
    work.endpoint = addr
}

func (work *btcWorker) getBlock(blockHeight int64) (*blockDesc, error) {
    // 1. 获取块hash
    b, err := work.request("getblockhash", []interface{}{blockHeight})
    if err != nil {
        return nil, err
    }
    hash := string(b[11:75]) //data := strings.Trim(string(b), "\n")

    // 2. 获取块数据
    b, err = work.request("getblock", []interface{}{hash, 2})
    if err != nil {
        return nil, err
    }

    // 3. 解析
    var block blockDesc
    err = json.Unmarshal(b, &block)
    if err != nil {
        return nil, err
    }
    if block.Error != nil {
        return nil, errors.New("response error from RPC")
    }

    return &block, nil
}

// https://developer.bitcoin.org/reference/rpc/getblock.html
func (work *btcWorker) parseBlockTx(blockHeight int64) ([]string, error) {

    // 1. 文件句柄
    var err error
    if blockHeight%10000 == 0 {
        if fhIn != nil {
            fhIn.Close()
        }
        if fhOut != nil {
            fhOut.Close()
        }
        backIn := "txin" + fmt.Sprintf("%03d", blockHeight/10000)
        backOut := "txou" + fmt.Sprintf("%03d", blockHeight/10000)
        fhIn, err = os.OpenFile(homeDir()+"/"+dirTX+"/"+backIn, os.O_RDWR|os.O_CREATE|os.O_APPEND, 0644)
        if err != nil {
            log.Errorln(err)
        }
        fhOut, err = os.OpenFile(homeDir()+"/"+dirTX+"/"+backOut, os.O_RDWR|os.O_CREATE|os.O_APPEND, 0644)
        if err != nil {
            log.Errorln(err)
        }
    }

    // 2. 区块数据
    var block *blockDesc
    block, err = work.getBlock(blockHeight)
    if err != nil {
        log.Errorln(err)
    }

    // 5. 解析 tx
    for index, item := range block.Result.Tx {
        // 解析 CoinBase tx
        if index == 0 {
            txC := new(txCoinBase)
            if err = json.Unmarshal(item, &txC); err != nil {
                return nil, err
            }

            var setN []int
            for _, vo := range txC.Vout {
                setN = append(setN, vo.N)
            }
            work.txSaveToFile(fhOut, txC.Txid, setN)
            continue
        }

        // 解析其他tx
        txN := new(txNormal)
        if err = json.Unmarshal(item, &txN); err != nil {
            return nil, err
        }

        for _, vi := range txN.Vin {
            work.txSaveToFile(fhIn, vi.Txid, []int{vi.Vout})
        }

        var setN []int
        for _, vo := range txN.Vout {
            setN = append(setN, vo.N)
        }
        work.txSaveToFile(fhOut, txN.Txid, setN)
    }

    return nil, nil
}

func (work *btcWorker) txSaveToFile(fh *os.File, tx string, index []int) error {
    var s []string
    for _, item := range index {
        s = append(s, strconv.Itoa(item))
    }
    _, err := fh.WriteString(tx + " " + strings.Join(s, ",") + "\n")
    if err != nil {
        log.Println(err)
    }
    return nil
}

func (work *btcWorker) saveToFile(fh *os.File, data string) error {
    _, err := fh.WriteString(data + "\n")
    if err != nil {
        log.Println(err)
    }
    return nil
}

// https://developer.bitcoin.org/reference/rpc/gettxout.html
func (work *btcWorker) getTxOut(tx string, index int) ([]string, error) {
    b, err := work.request("gettxout", []interface{}{tx, index})
    if err != nil {
        return nil, err
    }

    type desc struct {
        Result struct {
            Bestblock     string  `json:"bestblock"`
            Confirmations int     `json:"confirmations"`
            Value         float64 `json:"value"`
            ScriptPubKey  struct {
                Asm       string   `json:"asm"`
                Hex       string   `json:"hex"`
                ReqSigs   int      `json:"reqSigs"`
                Type      string   `json:"type"`
                Addresses []string `json:"addresses"`
            } `json:"scriptPubKey"`
            Coinbase bool `json:"coinbase"`
        } `json:"result"`
        Error interface{} `json:"error"`
        ID    string      `json:"id"`
    }
    var txOut desc
    if err = json.Unmarshal(b, &txOut); err != nil {
        return nil, err
    }

    return txOut.Result.ScriptPubKey.Addresses, nil
}

// n 0
func (work *btcWorker) memTXIn(tx string, n string) error {

    out, err := redis.String(work.redis.Do("HGET", keyNameTxOut, tx))
    if err != nil {
        return err
    }
    str := strings.Split(out, ",")

    for idx, s := range str {
        if s == n {
            str = append(str[:idx], str[idx+1:]...)
        }
    }
    if len(str) == 0 {
        if _, err := work.redis.Do("HDEL", keyNameTxOut, tx); err != nil {
            return err
        }
        return nil
    }

    if _, err := work.redis.Do("HSET", keyNameTxOut, tx, strings.Join(str, ",")); err != nil {
        return err
    }

    return nil
}

// nAll 0,1,2,3
func (work *btcWorker) memTXOut(tx string, nAll string) error {

    if _, err := work.redis.Do("HSET", keyNameTxOut, tx, nAll); err != nil {
        return err
    }
    return nil
}

func (work *btcWorker) addrSaveToHash160(addr string) {
    address, err := bitcoin.ParseAddress(addr)
    if err != nil {
        log.Println(err)
        return
    }
    address.Hash160()
    work.redis.Send("SADD", keyNameHash160, hex.EncodeToString(address.Hash160()))
}

// 导出 vin vout
func (work *btcWorker) WorkBlockTx(from, to int64) {
    log.Println("-----------------")
    log.Println(time.Now().Format(time.RFC3339))
    log.Println("开始....")
    log.Println("存储位置:", workDir(dirTX))

    t1 := time.Now().Unix()

    for i := from; i < to; i++ {
        log.Println("进度:", i)
        work.parseBlockTx(i)
    }
    t2 := time.Now().Unix()
    log.Println(time.Now().Format(time.RFC3339))
    log.Println("耗时:", t2-t1)
    log.Println("结束....")
    log.Println("-----------------")
}

// 通过 vin vout 计算 utxo
// 文件编号 from to 0-64; 即块高度 / 10000
func (work *btcWorker) WorkBlockUTXO(from, to int64) {
    log.Println("-----------------")
    log.Println(time.Now().Format(time.RFC3339))
    log.Println("开始....")

    if from > 100 || to > 100 {
        log.Errorln("请指定正确的文件编号")
        os.Exit(0)
    }

    var err error
    t1 := time.Now().Unix()
    for i := from; i < to; i++ {
        sn := fmt.Sprintf("%03d", i)
        log.Println("进度文件编号", sn)

        // 1. 文件句柄
        if fhIn != nil {
            fhIn.Close()
        }
        if fhOut != nil {
            fhOut.Close()
        }
        fileIn := "txin" + sn
        fileOut := "txou" + sn
        fhIn, err = os.OpenFile(homeDir()+"/"+dirTX+"/"+fileIn, os.O_RDONLY, 0644)
        if err != nil {
            log.Println(err)
            return
        }
        fhOut, err = os.OpenFile(homeDir()+"/"+dirTX+"/"+fileOut, os.O_RDONLY, 0644)
        if err != nil {
            log.Println(err)
            return
        }

        // 2. 逐行处理

        // vout
        log.Println("添加OUT条目")
        r := bufio.NewReader(fhOut)
        for {
            lineBytes, err := r.ReadBytes(byte(10))
            if err == io.EOF {
                break
            }
            line := strings.Trim(string(lineBytes), "\n")
            one := strings.Split(line, " ")
            if len(one) <= 1 {
                log.Errorln("error data:", line)
                os.Exit(0)
            }
            work.memTXOut(one[0], one[1])
        }

        // vin
        log.Println("删除VIN条目")
        r = bufio.NewReader(fhIn)
        for {
            line, err := r.ReadString('\n')
            if err == io.EOF {
                break
            }
            one := strings.Split(line, " ")
            work.memTXIn(one[0], one[1])
        }
    }
    t2 := time.Now().Unix()

    log.Println(time.Now().Format(time.RFC3339))
    log.Println("耗时:", t2-t1)
    log.Println("结束....")
    log.Println("-----------------")
}

func (work *btcWorker) WorkBlockAddress() {

    // 遍历 hash
    nextId := "0"
    loop := 0
    for {
        log.Println("序列与游标:", loop, nextId)
        loop++
        out, err := work.redis.Do("HSCAN", keyNameTxOut, nextId)
        if err != nil {
            log.Errorln(err)
            os.Exit(0)
        }
        all := out.([]interface{})
        nextId = string(all[0].([]byte))
        if nextId == "0" {
            log.Println("任务完成")
            break
        }

        // 数据
        data := all[1].([]interface{})
        type holder struct {
            tx string
            n  string
        }

        result := make([]holder, 0)
        for i := 0; i < len(data)/2; i++ {
            k := string(data[2*i].([]byte))
            v := string(data[2*i+1].([]byte))
            result = append(result, holder{
                tx: k,
                n:  v,
            })
        }

        // 调用
        for _, item := range result {
            for _, n := range strings.Split(item.n, ",") {
                idx, err := strconv.Atoi(n)
                if err != nil {
                    log.Errorln(err)
                    continue
                }
                out, err := work.getTxOut(item.tx, idx)
                if err != nil {
                    log.Errorln(err)
                    continue
                }
                for _, addr := range out {
                    work.addrSaveToHash160(addr)
                }
            }
        }
    }
}

// 读块，获取所有地址，hash160 后写入文件 hash160.001
func (work *btcWorker) WorkAllAddress(snFrom, snTo int64) {
    log.Println("工作目录:", workDir("address"))

    type vOutType struct {
        TxId string `json:"txid"`
        VOut []vOutDesc
    }

    var fh *os.File
    var err error

    step := int64(10000)
    for i := snFrom; i < snTo; i++ {
        offset := i * step

        // 1.
        if fh != nil {
            fh.Close()
        }
        filename := "hash160." + fmt.Sprintf("%03d", i)
        fh, err = os.OpenFile(homeDir()+"/address/"+filename, os.O_RDWR|os.O_CREATE|os.O_APPEND, 0644)
        if err != nil {
            log.Errorln(err)
        }

        // 2.
        for j := int64(0); j < step; j++ {
            // hash160 字典， 用于去重
            hashData := make(map[string]bool)

            // 1>. 查询块
            blockHeight := offset + j
            log.Println("处理块:", blockHeight)
            block, err := work.getBlock(blockHeight)
            if err != nil {
                log.Errorln(err)
                return
            }

            // 2>. 解析 tx
            for _, item := range block.Result.Tx {

                out := new(vOutType)
                if err = json.Unmarshal(item, &out); err != nil {
                    log.Println(err)
                    continue
                }

                for _, value := range out.VOut {
                    switch value.ScriptPubKey.Type {
                    case "nulldata":
                        continue
                    case "nonstandard":
                        log.Println("非标类型: nonstandard", out.TxId)
                    case "pubkey":
                        l := len(value.ScriptPubKey.Hex)
                        pubKey, _ := hex.DecodeString(value.ScriptPubKey.Hex[2 : l-2])
                        h160 := hex.EncodeToString(bitcoin.Hash160(pubKey))
                        hashData[h160] = true
                    case "multisig":
                        for _, addr := range value.ScriptPubKey.Addresses {
                            ad, _ := bitcoin.ParseAddress(addr)
                            h160 := hex.EncodeToString(ad.Hash160())
                            hashData[h160] = true
                        }
                    case "scripthash", "pubkeyhash":
                        for _, addr := range value.ScriptPubKey.Addresses {
                            ad, _ := bitcoin.ParseAddress(addr)
                            h160 := hex.EncodeToString(ad.Hash160())
                            hashData[h160] = true
                        }
                    case "witness_v0_keyhash", "witness_v0_scripthash": // 有空地址
                        for _, addr := range value.ScriptPubKey.Addresses {
                            ad, _ := bitcoin.ParseAddress(addr)

                            h160 := hex.EncodeToString(ad.Hash160())
                            hashData[h160] = true
                        }
                    default:
                        log.Errorln("未知类型", value.ScriptPubKey.Type, out.TxId)
                    }
                }
            }

            // 3>. 存储 hash160
            for h160, _ := range hashData {
                work.saveToFile(fh, h160)
            }

            // os.Exit(0)
        }
    }
}

// 爆破
func (work *btcWorker) WorkCrack() {
    dir := "output"
    log.Println(workDir(dir))

    // 1. 过滤器
    log.Println("准备过滤器")
    bf, err := work.prepareDataForFilter()
    work.bfData = bf
    if err != nil {
        log.Errorln(err)
        os.Exit(0)
    }
    log.Println("过滤器准备完成")

    // 2. 文件句柄
    source := os.Getenv("BF_INPUT")
    inH, err := os.OpenFile(source, os.O_RDONLY, 0644)
    if err != nil {
        log.Errorln(err)
        os.Exit(0)
    }
    outH, err := os.OpenFile(workDir(dir)+"/crack.txt", os.O_RDWR|os.O_CREATE|os.O_APPEND, 0644)
    if err != nil {
        log.Errorln(err)
        os.Exit(0)
    }

    // 3. 多线程爆破
    ch := make(chan string, numCPU)
    for i := 0; i < numCPU; i++ {
        w.Add(1)
        go func(id int) {
            for {
                data, ok := <-ch
                if ok {
                    resp, ok := work.crackFindResult(data)
                    if ok {
                        log.Println("SUC:", resp)
                        outH.WriteString(resp + "\n")
                    }
                } else {
                    log.Println("线程:", id, "已全部处理")
                    w.Done()
                    return
                }
            }
        }(i)
    }
    // ---------

    // 4. 准备数据
    r := bufio.NewReader(inH)
    loop := 0
    for {
        loop++
        log.Println("尝试行:", loop)
        line, err := r.ReadString('\n')
        if err == io.EOF {
            break
        }
        line = strings.Trim(line, "\n")
        ch <- line
    }
    close(ch)

    // wait
    w.Wait()
}

func (work *btcWorker) prepareDataForFilter() (*bloomFilter, error) {
    fh, err := os.OpenFile(os.Getenv("BF_DATA"), os.O_RDONLY, 0644)
    if err != nil {
        return nil, err
    }
    defer fh.Close()

    size, err := strconv.ParseInt(os.Getenv("BF_SIZE"), 10, 64)
    if err != nil {
        return nil, err
    }
    filter := NewBloomFilter(uint64(size) * 1024 * 1024)
    r := bufio.NewReader(fh)
    for {
        str, err := r.ReadString('\n')
        if err == io.EOF {
            break
        }
        filter.Add([]byte(strings.Trim(str, "\n")))
    }
    return filter, nil
}

func (work *btcWorker) crackFindResult(keyword string) (string, bool) {
    words := strings.TrimSpace(keyword)
    sha, _ := hashSha256([]byte(words))
    pri, _ := bitcoin.NewPriKey(sha)
    pub1 := pri.PubKey()
    pub2 := pri.PubKeyUncompressed()

    h1, _ := hash160(pub1.Key())
    h2, _ := hash160(pub2.Key())
    s1 := hex.EncodeToString(h1)
    s2 := hex.EncodeToString(h2)

    if work.bfData.Contains([]byte(s1)) {
        return s1 + ":c:str:" + words, true
    }
    if work.bfData.Contains([]byte(s2)) {
        return s2 + ":u:str:" + words, true
    }

    // 返回格式
    // 8b0a993126c3bf8f4b28c8264b553d6aa39f2956:u:str:Money is the root of all evil.
    return "", false
}

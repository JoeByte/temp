package core

import (
    "bufio"
    "bytes"
    "crypto/md5"
    "encoding/binary"
    "fmt"
    log "github.com/sirupsen/logrus"
    "os"
)

var (
    bfMapTimes = 2 // md5 16 bits
    bfDataFile = "data.dat"
)

type bloomFilter struct {
    size uint64
    bits uint64
    data []byte
}

func NewBloomFilter(size uint64) *bloomFilter {
    return &bloomFilter{
        size: size,
        bits: size * 8,
        data: make([]byte, size),
    }
}

func (bf *bloomFilter) Add(data []byte) {
    h := bf.hash(data)
    for i := 0; i < bfMapTimes; i++ {
        idx1 := i * 8
        idx2 := idx1 + 8

        n, m := bf.position(bf.bytesToInt(h[idx1:idx2]))
        d := bf.data[n]
        bf.data[n] = 1<<m | d
    }
}

func (bf *bloomFilter) Contains(data []byte) bool {
    h := bf.hash(data)
    for i := 0; i < bfMapTimes; i++ {
        idx1 := i * 8
        idx2 := idx1 + 8

        n, m := bf.position(bf.bytesToInt(h[idx1:idx2]))
        if (1 << m & bf.data[n]) == 0 {
            return false
        }
    }
    return true
}

func (bf *bloomFilter) SaveMemData() error {
    fh, err := os.OpenFile(homeDir()+"/"+bfDataFile, os.O_RDWR|os.O_CREATE|os.O_TRUNC, 0644)
    if err != nil {
        return err
    }
    fh.Write(bf.data)
    defer fh.Close()
    return nil
}

func (bf *bloomFilter) LoadMemData() error {
    f, err := os.Open(homeDir() + "/" + bfDataFile)
    if err != nil {
        return err
    }
    defer f.Close()
    // 整个读取
    // f.Read(bf.data)

    // 分片读取
    buf := bufio.NewReader(f)
    bs := uint64(4 * 1024 * 1024) // 4MB
    c := bf.size/bs + 1
    if bf.size%bs == 0 {
        c = bf.size / bs
    }
    for i := uint64(0); i < c; i++ {
        idx := i * bs
        if i+1 == c {
            buf.Read(bf.data[idx:])
        } else {
            buf.Read(bf.data[idx : idx+bs])
        }
    }
    return nil
}

func (bf *bloomFilter) bytesToInt(b []byte) uint64 {
    buffer := bytes.NewBuffer(b)
    var tmp uint64
    binary.Read(buffer, binary.BigEndian, &tmp)
    return tmp
}

func (bf *bloomFilter) hash(p []byte) []byte {
    // TODO :: 使用更快速的hash算法
    h := md5.New()
    h.Write(p)
    return h.Sum(nil)
}

func (bf *bloomFilter) position(number uint64) (uint64, uint8) {
    p := number % bf.bits
    n := p / 8
    m := p % 8
    return n, uint8(m)
}

func (bf *bloomFilter) Debug() {
    if bf.bits <= 1024 {
        log.Println(fmt.Sprintf("%b", bf.data))
    } else {
        log.Println(fmt.Sprintf("%b", bf.data[0:1024]))
    }
}

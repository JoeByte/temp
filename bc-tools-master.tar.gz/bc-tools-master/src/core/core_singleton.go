package core

import (
    "database/sql"
    _ "github.com/go-sql-driver/mysql"
    "github.com/gomodule/redigo/redis"
    "log"
    "os"
    "sync"
    "time"
)

var (
    once     sync.Once
    instance *singleton
)

type singleton struct {
    redis *redis.Pool
    mysql *sql.DB
}

func Instance() *singleton {
    once.Do(func() {
        instance = &singleton{}
    })
    return instance
}

func (ins *singleton) MySql() (*sql.DB, error) {
    if ins.mysql == nil {
        var err error
        ins.mysql, err = getMysqlInstance()
        if err != nil {
            return nil, err
        }
    }
    return ins.mysql, nil
}

func (ins *singleton) Redis() (*redis.Pool, error) {
    if ins.redis == nil {
        var err error
        ins.redis, err = getRedisInstance()
        if err != nil {
            return nil, err
        }
    }
    return ins.redis, nil
}

func getMysqlInstance() (*sql.DB, error) {
    // @docs http://go-database-sql.org/retrieving.html
    // @docs https://github.com/go-sql-driver/mysql/wiki/Examples
    host := os.Getenv("DB_HOST")
    port := os.Getenv("DB_PORT")
    name := os.Getenv("DB_NAME")
    user := os.Getenv("DB_USER")
    pass := os.Getenv("DB_PASS")
    dsn := user + ":" + pass + "@tcp(" + host + ":" + port + ")/" + name

    db, err := sql.Open("mysql", dsn)
    if err != nil {
        return nil, err
    }
    db.SetConnMaxLifetime(10 * time.Minute)
    db.SetMaxIdleConns(3)
    db.SetMaxOpenConns(20)

    //defer db.Close()

    err = db.Ping()
    if err != nil {
        return nil, err
    }
    return db, nil
}

func getRedisInstance() (*redis.Pool, error) {
    return &redis.Pool{
        MaxIdle:     20,
        MaxActive:   1000,
        IdleTimeout: 300 * time.Second,
        Dial: func() (redis.Conn, error) {
            c, err := redis.Dial("tcp", os.Getenv("REDIS_HOST")+":"+os.Getenv("REDIS_PORT"))
            if err != nil {
                log.Println(err.Error())
                return nil, err
            }
            if _, err := c.Do("SELECT", os.Getenv("REDIS_DB")); err != nil {
                c.Close()
                return nil, err
            }
            return c, nil
        },
    }, nil
}

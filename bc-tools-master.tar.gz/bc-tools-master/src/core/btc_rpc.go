package core

import (
    "encoding/base64"
    "encoding/json"
    "errors"
    "fmt"
    "github.com/zlabwork/go-zlibs"
    "io/ioutil"
    "math"
    "strings"
)

const (
    minAmount = 0.00000546
)

type UTXO struct {
    Tx  string
    N   int
    Amt float64
}

// default rpc port: 8332, regtest: 18443
type ParamRPC struct {
    Endpoint string
    RpcUser  string
    RpcPass  string
}

type rpcBTC struct {
    req   *zlibs.HttpLib
    param ParamRPC
}

func NewRpcBTC(param *ParamRPC) *rpcBTC {
    return &rpcBTC{
        param: *param,
        req:   zlibs.NewHttpLib(),
    }
}

func (rpc *rpcBTC) request(method string, params []interface{}) ([]byte, error) {
    reqId := uniqueID()
    type rd struct {
        Jsonrpc string        `json:"jsonrpc"`
        Id      string        `json:"id"`
        Method  string        `json:"method"`
        Params  []interface{} `json:"params"`
    }

    b, err := json.Marshal(rd{
        Jsonrpc: "1.0",
        Id:      reqId,
        Method:  method,
        Params:  params,
    })
    if err != nil {
        return nil, err
    }
    data := string(b)
    header := make(map[string]string)
    token := base64.StdEncoding.EncodeToString([]byte(rpc.param.RpcUser + ":" + rpc.param.RpcPass))
    header["Authorization"] = "Basic " + token
    rpc.req.SetHeaders(header)
    resp, err := rpc.req.RequestRaw("POST", rpc.param.Endpoint, []byte(data))
    if err != nil {
        return nil, err
    }
    defer resp.Body.Close()

    body, err := ioutil.ReadAll(resp.Body)
    if resp.StatusCode != 200 {
        return nil, errors.New(fmt.Sprintf("code: %d, message: %s", resp.StatusCode, strings.Trim(string(body), "\n")))
    }
    return body, err
}

func (rpc *rpcBTC) CreateTX(in []UTXO, out map[string]float64, sat int, backAddr string) (hex string, error error) {

    // 1. total in
    var totalIn float64
    for _, tx := range in {
        if tx.Amt < minAmount {
            return "", errors.New(fmt.Sprintf("min allow amount %d sat", int64(minAmount*math.Pow(10, 8))))
        }
        totalIn += tx.Amt
    }

    // 2. total out
    var totalOut float64
    for _, amt := range out {
        if amt < minAmount {
            return "", errors.New(fmt.Sprintf("min allow amount %d sat", int64(minAmount*math.Pow(10, 8))))
        }
        totalOut += amt
    }

    // 3. fee sat
    size := 148*len(in) + 34*len(out) + 10
    fee := size * sat
    thresholdSat := 34*int64(sat) + int64(minAmount*math.Pow10(8)) // sat

    // 4. charge back
    charge := totalIn - totalOut - float64(fee)*math.Pow10(-8)
    if charge < 0 {
        return "", errors.New("fee is not enough")
    }
    if int64(charge*math.Pow10(8)) > thresholdSat {
        out[backAddr] = charge
        fee += 34 * sat
    }

    return rpc.CreateRawTX(in, out)
}

// https://developer.bitcoin.org/reference/rpc/createrawtransaction.html
func (rpc *rpcBTC) CreateRawTX(in []UTXO, out map[string]float64) (hex string, error error) {

    // 1. check
    if len(in) < 1 {
        return "", errors.New("no inputs")
    }
    if len(out) < 1 {
        return "", errors.New("no outputs")
    }
    for _, t := range out {
        if t < minAmount {
            return "", errors.New(fmt.Sprintf("min allow amount %d sat", int64(minAmount*math.Pow(10, 8))))
        }
    }

    // 2.
    type inType struct {
        TxId string `json:"txid"`
        VOut int    `json:"vout"`
    }
    var inData []inType
    for _, item := range in {
        var tmp inType
        if len(item.Tx) != 64 {
            return "", errors.New("error transaction: " + item.Tx)
        }
        tmp.TxId = item.Tx
        tmp.VOut = item.N
        inData = append(inData, tmp)
    }
    param := []interface{}{inData, out}

    // 3.
    b, err := rpc.request("createrawtransaction", param)
    if err != nil {
        return "", err
    }

    // 4. parse
    type desc struct {
        Result string      `json:"result"`
        Error  interface{} `json:"error"`
        ID     string      `json:"id"`
    }
    var resp desc
    err = json.Unmarshal(b, &resp)
    if err != nil {
        return "", err
    }
    if resp.Error != nil {
        return "", errors.New("error return, reqId: " + resp.ID)
    }

    return resp.Result, nil
}

// https://developer.bitcoin.org/reference/rpc/signrawtransactionwithkey.html
func (rpc *rpcBTC) SignRawTX(hex string, keys []string) (string, error) {

    // 1.
    param := []interface{}{hex, keys}
    b, err := rpc.request("signrawtransactionwithkey", param)
    if err != nil {
        return "", err
    }

    // 2.
    type desc struct {
        Result struct {
            Hex      string `json:"hex"`
            Complete bool   `json:"complete"`
        } `json:"result"`
        Error interface{} `json:"error"`
        ID    string      `json:"id"`
    }
    var resp desc
    err = json.Unmarshal(b, &resp)
    if err != nil {
        return "", err
    }
    if resp.Result.Complete != true {
        return "", errors.New("sign is not complete")
    }

    return resp.Result.Hex, err
}

// https://developer.bitcoin.org/reference/rpc/sendrawtransaction.html
// 失败: 报错500, 可使用命令行测试问题
// 格式: bitcoin-cli sendrawtransaction <signedHex>
// ---------------
// 报错1: Fee exceeds maximum configured by user (e.g. -maxtxfee, maxfeerate)
// 报错2: min relay fee not met, 100 < 141
// 原因: 手续费用太高或太低
func (rpc *rpcBTC) SendTX(signedHex string) (tx string, error error) {
    param := []interface{}{signedHex}
    b, err := rpc.request("sendrawtransaction", param)
    if err != nil {
        return "", errors.New(err.Error() + "; it maybe invalid fee or txn-mempool-conflict; try test command `bitcoin-cli sendrawtransaction <signedHex>`")
    }

    type desc struct {
        Result string      `json:"result"`
        Error  interface{} `json:"error"`
        ID     string      `json:"id"`
    }
    var resp desc
    err = json.Unmarshal(b, &resp)
    if err != nil {
        return "", err
    }

    return resp.Result, nil
}

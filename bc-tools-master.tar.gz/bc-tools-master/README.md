## 使用合约

```golang
// 初始化
cli, err := ethclient.Dial("http://127.0.0.1:8545")
if err != nil {
	log.Panic(err)
}
contract, err := libs.NewContractAt("0x6bAF2890703663ab8Aa94996bAcd5c64774c8a28", cli)
```

```golang
// 查询余额 - 方法1
contract.BalanceOf("0x4b00a4a87a31bb22a38c796f1853ab5a25cd0e9b")
```

```golang
// 查询余额 - 方法2
opts := &bind.CallOpts{}
addr := common.HexToAddress("0x4b00a4a87a31bb22a38c796f1853ab5a25cd0e9b")
contract.Common.BalanceOf(opts, addr)
```


## 工具
[https://mholt.github.io/json-to-go/](https://mholt.github.io/json-to-go/)  
[Hash160 To Address](https://learnmeabitcoin.com/technical/address)


## docs
[https://learnmeabitcoin.com/technical/txid](https://learnmeabitcoin.com/technical/txid)  
[布隆过滤器的误判率该如何计算](https://www.zhihu.com/question/38573286)  
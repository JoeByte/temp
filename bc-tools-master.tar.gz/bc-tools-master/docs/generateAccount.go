package main

import (
	"os"
	"log"
	"fmt"
	"regexp"
	"encoding/hex"
	"github.com/joho/godotenv"
	"github.com/ethereum/go-ethereum/crypto"
)

func main() {

	err := godotenv.Load()
	if err != nil {
		log.Fatal(err)
		os.Exit(0)
	}

	var i int = 0
	for {

		//Create an account
		key, _ := crypto.GenerateKey()

		//Get the address
		address := crypto.PubkeyToAddress(key.PublicKey).Hex()

		//Get the private key
		privateKey := hex.EncodeToString(key.D.Bytes())

		// 正则匹配
		reg := regexp.MustCompile(`(0{4,}|1{4,}|6{4,}|8{4,}|a{4,}|b{4,}|c{4,}|d{4,}|e{4,}|f{4,}|A{4,}|B{4,}|C{4,}|D{4,}|E{4,}|F{4,})$`)
		//reg := regexp.MustCompile(`0{4,}|1{4,}|6{4,}|8{4,}|a{4,}|b{4,}|c{4,}|d{4,}|e{4,}|f{4,}|A{4,}|B{4,}|C{4,}|D{4,}|E{4,}|F{4,}$`)
		if reg.MatchString(address) {
			fmt.Println(address, " - ", privateKey)
		}

		if i >= 1000000 {
			break
		}
		i++
	}

}

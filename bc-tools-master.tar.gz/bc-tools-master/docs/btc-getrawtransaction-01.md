joe@space:~$ bitcoin-cli getrawtransaction fff2525b8931402dd09222c50775608f75787bd2b87e56995a7bdd30f79702c4 true 000000000003ba27aa200b1cecaad478d2b00432346c3f1f3986da1afd33e506 
{
  "in_active_chain": true,
  "txid": "fff2525b8931402dd09222c50775608f75787bd2b87e56995a7bdd30f79702c4",
  "hash": "fff2525b8931402dd09222c50775608f75787bd2b87e56995a7bdd30f79702c4",
  "version": 1,
  "size": 259,
  "vsize": 259,
  "weight": 1036,
  "locktime": 0,
  "vin": [
    {
      "txid": "87a157f3fd88ac7907c05fc55e271dc4acdc5605d187d646604ca8c0e9382e03",
      "vout": 0,
      "scriptSig": {
        "asm": "3046022100c352d3dd993a981beba4a63ad15c209275ca9470abfcd57da93b58e4eb5dce82022100840792bc1f456062819f15d33ee7055cf7b5ee1af1ebcc6028d9cdb1c3af7748[ALL] 04f46db5e9d61a9dc27b8d64ad23e7383a4e6ca164593c2527c038c0857eb67ee8e825dca65046b82c9331586c82e0fd1f633f25f87c161bc6f8a630121df2b3d3",
        "hex": "493046022100c352d3dd993a981beba4a63ad15c209275ca9470abfcd57da93b58e4eb5dce82022100840792bc1f456062819f15d33ee7055cf7b5ee1af1ebcc6028d9cdb1c3af7748014104f46db5e9d61a9dc27b8d64ad23e7383a4e6ca164593c2527c038c0857eb67ee8e825dca65046b82c9331586c82e0fd1f633f25f87c161bc6f8a630121df2b3d3"
      },
      "sequence": 4294967295
    }
  ],
  "vout": [
    {
      "value": 5.56000000,
      "n": 0,
      "scriptPubKey": {
        "asm": "OP_DUP OP_HASH160 c398efa9c392ba6013c5e04ee729755ef7f58b32 OP_EQUALVERIFY OP_CHECKSIG",
        "hex": "76a914c398efa9c392ba6013c5e04ee729755ef7f58b3288ac",
        "reqSigs": 1,
        "type": "pubkeyhash",
        "addresses": [
          "1JqDybm2nWTENrHvMyafbSXXtTk5Uv5QAn"
        ]
      }
    },
    {
      "value": 44.44000000,
      "n": 1,
      "scriptPubKey": {
        "asm": "OP_DUP OP_HASH160 948c765a6914d43f2a7ac177da2c2f6b52de3d7c OP_EQUALVERIFY OP_CHECKSIG",
        "hex": "76a914948c765a6914d43f2a7ac177da2c2f6b52de3d7c88ac",
        "reqSigs": 1,
        "type": "pubkeyhash",
        "addresses": [
          "1EYTGtG4LnFfiMvjJdsU7GMGCQvsRSjYhx"
        ]
      }
    }
  ],
  "hex": "0100000001032e38e9c0a84c6046d687d10556dcacc41d275ec55fc00779ac88fdf357a187000000008c493046022100c352d3dd993a981beba4a63ad15c209275ca9470abfcd57da93b58e4eb5dce82022100840792bc1f456062819f15d33ee7055cf7b5ee1af1ebcc6028d9cdb1c3af7748014104f46db5e9d61a9dc27b8d64ad23e7383a4e6ca164593c2527c038c0857eb67ee8e825dca65046b82c9331586c82e0fd1f633f25f87c161bc6f8a630121df2b3d3ffffffff0200e32321000000001976a914c398efa9c392ba6013c5e04ee729755ef7f58b3288ac000fe208010000001976a914948c765a6914d43f2a7ac177da2c2f6b52de3d7c88ac00000000",
  "blockhash": "000000000003ba27aa200b1cecaad478d2b00432346c3f1f3986da1afd33e506",
  "confirmations": 571207,
  "time": 1293623863,
  "blocktime": 1293623863
}
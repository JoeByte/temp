package main

import (
    "bc-tools/src/core"
    "flag"
    "fmt"
    "github.com/joho/godotenv"
    log "github.com/sirupsen/logrus"
    "os"
    "strconv"
)

func main() {
    err := godotenv.Load(".env")
    if err != nil {
        log.Fatal(err)
    }
    core.InitHomeEnv()

    var method string
    flag.StringVar(&method, "m", "", "input method name")
    flag.Parse()

    switch method {
    case "bloom":
        workBloom()
    case "txout1":
        workTXOut1()
    case "txout2":
        workTXOut2()
    case "txout3":
        workTXOut3()
    case "address":
        workAllAddress()
    case "crack":
        crack()
    default:
        fmt.Println("usage:")
        fmt.Println(" cmd -m bloom")
        fmt.Println(" cmd -m txout1	save all tx to file, ex: txin001.")
        fmt.Println(" cmd -m txout2	read data(txin001), then save to redis utxo.")
        fmt.Println(" cmd -m txout3	read from redis utxo, then save to redis hash160")
        fmt.Println(" cmd -m address	read from block RPC, then save all address")
        fmt.Println(" cmd -m crack	crack data")
    }
}

func workBloom() {
    bf := core.NewBloomFilter(1 * 100)
    for i := 0; i < 100; i++ {
        bf.Add([]byte(strconv.Itoa(i)))
    }
    bf.Debug()
    log.Println(bf.Contains([]byte("110")))
}

// 导出到文件
func workTXOut1() {
    bc := core.NewBTCSync()
    bc.SetEndpoint(os.Getenv("BTC_RPC_API"))
    bc.WorkBlockTx(0, 670000)
}

// 读取文件计算 UTXO 写入 redis
func workTXOut2() {
    bc := core.NewBTCSync()
    bc.WorkBlockUTXO(0, 67)
}

// UTXO 转换 地址
func workTXOut3() {
    bc := core.NewBTCSync()
    bc.SetEndpoint(os.Getenv("BTC_RPC_API"))
    bc.WorkBlockAddress()
}

// 所有地址
// sn 0-10: block 0-100000
func workAllAddress() {
    bc := core.NewBTCSync()
    bc.SetEndpoint(os.Getenv("BTC_RPC_API"))
    bc.WorkAllAddress(0, 67)
}

// 爆破
func crack() {
    bc := core.NewBTCSync()
    bc.WorkCrack()
}
